'use strict';
var path = require('path');
var server = require(path.resolve(__dirname, '../..'));
var datasource = server.datasources.loopback;

module.exports = function (ProductBasket) {

    ProductBasket.calcTotal = function (prodId, cb) {

        // console.log(prodId);
        /*
         -->  ProdId is a unique value for every user or guest user based on that id we are validating and calculating data.
         -->  After getting count from PRODUCT_BASKET tabel i done calculation part.
         -->  if total_Count is more then or equals 3 then only i done calculation as per rquirement.Else storing in PRODUCT_BASKET_DISCOUNT.
         -->  PRODUCT_BASKET_DISCOUNT is used to store calculation of basket.
         -->  Same for prodB()
         -->  There is no calculation part in C and D jo just returning after multiplying by Totalcount. 
        */
        ProductBasket.findOne({ where: { prodId: prodId } }, function (err, res) {
            if (res != null) {
                let ProdA = () => {
                    return new Promise((resolve, reject) => {

                        let prodA_Price = 30;
                        var prodA_Discount = 15;
                        var total_Price = 0;
                        var total_Discount = 0;

                        let productBasket_CountItems = `SELECT COUNT(*) CNT FROM PRODUCT_BASKET WHERE PROD_PRICE = ${prodA_Price} AND PROD_ID = ${prodId}`
                        datasource.connector.execute(productBasket_CountItems, null, (err, resultObjects) => {
                            if (err) {
                                return err;
                            }
                            //        // console.log(resultObjects);
                            let total_Count = resultObjects[0]["CNT"];
                            if (total_Count >= 3) {
                                let totalCount_DivData = total_Count / 3;
                                // console.log(totalCount_DivData);
                                let discount_Multiplier = ~~totalCount_DivData;
                                // console.log(discount_Multiplier);
                                total_Discount = prodA_Discount * discount_Multiplier;
                                total_Price = prodA_Price * total_Count - total_Discount;

                                // console.log(total_Discount);
                                // console.log(total_Price);
                                let insert_Discount_Basket = `INSERT INTO PRODUCT_BASKET_DISCOUNT VALUES(${prodA_Price},${prodA_Discount},${total_Price},${total_Discount},${prodId})`;
                                // console.log(insert_Discount_Basket);
                                datasource.connector.execute(insert_Discount_Basket, null, (err, resultObjects) => {
                                    if (err) {
                                        reject(err);
                                    }
                                    // // console.log('after insert :' , resultObjects);
                                    let reso = {
                                        prodA_Price: prodA_Price,
                                        prodA_Discount: prodA_Discount,
                                        total_Price: total_Price,
                                        discount_Applied: total_Discount
                                    }
                                    resolve(reso);
                                });


                            } else {

                                total_Discount = 0;
                                total_Price = prodA_Price * total_Count;
                                let insert_Discount_Basket = `INSERT INTO PRODUCT_BASKET_DISCOUNT VALUES(${prodA_Price},${prodA_Discount},${total_Price},${total_Discount},${prodId})`;
                                datasource.connector.execute(insert_Discount_Basket, null, (err, resultObjects) => {
                                    if (err) {
                                        reject(err);
                                    }
                                    let reso = {
                                        prodA_Price: prodA_Price,
                                        prodA_Discount: prodA_Discount,
                                        total_Price: total_Price,
                                        discount_Applied: total_Discount
                                    }
                                    resolve(reso);
                                });
                            }
                        });
                    });
                }

                let ProdB = () => {
                    return new Promise((resolve, reject) => {

                        let prodB_Price = 20;
                        var prodB_Discount = 5;
                        var total_Price = 0;
                        var total_Discount = 0;

                        let productBasket_CountItems = `SELECT COUNT(*) CNT FROM PRODUCT_BASKET WHERE PROD_PRICE = ${prodB_Price} AND PROD_ID = ${prodId}`
                        datasource.connector.execute(productBasket_CountItems, null, (err, resultObjects) => {
                            if (err) {
                                reject(err);
                            }

                            //      // console.log(resultObjects);
                            let total_Count = resultObjects[0]["CNT"];
                            if (total_Count >= 2) {
                                let totalCount_DivData = total_Count / 2;
                                // console.log(totalCount_DivData);
                                let discount_Multiplier = ~~totalCount_DivData;
                                // console.log(discount_Multiplier);
                                total_Discount = prodB_Discount * discount_Multiplier;
                                total_Price = prodB_Price * total_Count - total_Discount;

                                // console.log(total_Discount);
                                // console.log(total_Price);
                                let insert_Discount_Basket = `INSERT INTO PRODUCT_BASKET_DISCOUNT VALUES(${prodB_Price},${prodB_Discount},${total_Price},${total_Discount},${prodId})`;
                                // console.log(insert_Discount_Basket);
                                datasource.connector.execute(insert_Discount_Basket, null, (err, resultObjects) => {
                                    if (err) {
                                        return err;
                                    }
                                    // // console.log('after insert :' , resultObjects);
                                    let reso = {
                                        prodB_Price: prodB_Price,
                                        prodB_Discount: prodB_Discount,
                                        total_Price: total_Price,
                                        discount_Applied: total_Discount
                                    }
                                    resolve(reso);
                                });


                            } else {

                                total_Discount = 0;
                                total_Price = prodB_Price * total_Count;
                                let insert_Discount_Basket = `INSERT INTO PRODUCT_BASKET_DISCOUNT VALUES(${prodB_Price},${prodB_Discount},${total_Price},${total_Discount},${prodId})`;
                                datasource.connector.execute(insert_Discount_Basket, null, (err, resultObjects) => {
                                    if (err) {
                                        reject(err);
                                    }
                                    let reso = {
                                        prodA_Price: prodB_Price,
                                        prodB_Discount: prodB_Discount,
                                        total_Price: total_Price,
                                        discount_Applied: total_Discount
                                    }
                                    resolve(reso);
                                });
                            }
                        });
                    });
                }


                let ProdC = () => {
                    return new Promise((resolve, reject) => {

                        let prodC_Price = 50;
                        var prodC_Discount = 0;
                        var total_Price = 0;
                        var total_Discount = 0;

                        let productBasket_CountItems = `SELECT COUNT(*) CNT FROM PRODUCT_BASKET WHERE PROD_PRICE = ${prodC_Price} AND PROD_ID = ${prodId}`
                        datasource.connector.execute(productBasket_CountItems, null, (err, resultObjects) => {
                            if (err) {
                                reject(err);
                            }

                            //      // console.log(resultObjects);
                            let total_Count = resultObjects[0]["CNT"];
                            total_Price = prodC_Price * total_Count;
                            let insert_Discount_Basket = `INSERT INTO PRODUCT_BASKET_DISCOUNT VALUES(${prodC_Price},${prodC_Discount},${total_Price},${total_Discount},${prodId})`;
                            // console.log(insert_Discount_Basket);
                            datasource.connector.execute(insert_Discount_Basket, null, (err, resultObjects) => {
                                if (err) {
                                    reject(err);
                                }
                                // // console.log('after insert :' , resultObjects);
                                let reso = {
                                    prodC_Price: prodC_Price,
                                    prodC_Discount: prodC_Discount,
                                    total_Price: total_Price,
                                    discount_Applied: total_Discount
                                }
                                resolve(reso);
                            });
                        });
                    });
                }


                let ProdD = () => {
                    return new Promise((resolve, reject) => {

                        let prodD_Price = 15;
                        var prodD_Discount = 0;
                        var total_Price = 0;
                        var total_Discount = 0;

                        let productBasket_CountItems = `SELECT COUNT(*) CNT FROM PRODUCT_BASKET WHERE PROD_PRICE = ${prodD_Price} AND PROD_ID = ${prodId}`;
                        datasource.connector.execute(productBasket_CountItems, null, (err, resultObjects) => {
                            if (err) {
                                reject(err);
                            }

                            //      // console.log(resultObjects);
                            let total_Count = resultObjects[0]["CNT"];
                            total_Price = prodD_Price * total_Count;
                            let insert_Discount_Basket = `INSERT INTO PRODUCT_BASKET_DISCOUNT VALUES(${prodD_Price},${prodD_Discount},${total_Price},${total_Discount},${prodId})`;
                            // console.log(insert_Discount_Basket);
                            datasource.connector.execute(insert_Discount_Basket, null, (err, resultObjects) => {
                                if (err) {
                                    reject(err);
                                }
                                // // console.log('after insert :' , resultObjects);
                                let reso = {
                                    prodD_Price: prodD_Price,
                                    prodD_Discount: prodD_Discount,
                                    total_Price: total_Price,
                                    discount_Applied: total_Discount
                                }
                                resolve(reso);
                            });
                        });
                    });
                }

                let Test_Calc = async function ExecuteData() {

                    /*
                      -->  arrBasket_Result is used to store all the result value after calculating basket.
                      -->  prodA and prodB having condition of discount else other do not.
                      -->  please go threw functiong.
                      -->  After storing data in arrBasket_Result we are calculating totalBasket_Price and totalDiscount_Basket based on condition.
                      -->  At last pushing payee basket amount after making diffrent object into arrBasket_Result and shown in callback response.
                      */
                    let arrBasket_Result = [];
                    let prodA = await ProdA();
                    arrBasket_Result.push(prodA);
                    //  console.log('resolve prod A promises :' ,prodA);
                    let prodB = await ProdB();
                    arrBasket_Result.push(prodB);
                    // console.log('resolve prod B promises :', prodB);
                    let prodC = await ProdC();
                    arrBasket_Result.push(prodC);
                    // console.log('resolve prod C promises :', prodC);
                    let prodD = await ProdD();
                    arrBasket_Result.push(prodD);
                    //    console.log('resolve prod D promises :', prodD);

                    //    console.log('last Array basket result :',arrBasket_Result);
                    var totalBasket_Price = 0;
                    var totalDiscount_Basket = 0;
                    arrBasket_Result.forEach((data) => {
                        totalBasket_Price += data.total_Price;
                        totalDiscount_Basket += data.discount_Applied;
                    })
                    var discountover_Basket = 20;
                     //console.log(totalBasket_Price);
                    if (totalBasket_Price > 150) {
                       let payeeAmount =  totalBasket_Price - discountover_Basket;
                        let totalDiscount_Is = totalDiscount_Basket + discountover_Basket;
                       // console.log(payeeAmount);
                        // console.log('total disc : ', totalDiscount_Is);
                        let payable = {
                            Total_Price: payeeAmount,
                            Total_Discount: totalDiscount_Is
                        }
                        // making route as basketCheckout_Price to diffrentiate object.
                        let objBasket_String = JSON.stringify({ 'basketCheckout_Price': {payable }});
                        // console.log('string data :', objBasket_String);
                        let addBasket_PayeeResponse = JSON.parse(objBasket_String);
                        arrBasket_Result.push(addBasket_PayeeResponse);
                        cb(null, arrBasket_Result);

                    } else {
                        let payable = {
                            Total_Price: totalBasket_Price,
                            Total_Discount: totalDiscount_Basket
                        }
                        let objBasket_String = JSON.stringify({ 'basketCheckout_Price': { payable } });
                        let addBasket_PayeeResponse = JSON.parse(objBasket_String);
                        arrBasket_Result.push(addBasket_PayeeResponse);
                        cb(null, arrBasket_Result);
                    }
                }
                Test_Calc();
            } else {
                let resp = {
                    message: 'Oops Somethings went wrong !!!!!!'
                }
                cb(null, resp);
            }

        })
    }

    ProductBasket.remoteMethod('calcTotal', {
        http: { path: '/calcItems', verb: 'get' },
        accepts: { arg: 'prodId', type: 'String', 'http': { source: 'query' } },
        returns: { arg: 'resultObjects', type: 'object', root: true }
    });
    /////////////////////  Add Items into Basket //////////////////////////////

    ProductBasket.addItems = function (data, cb) {
        var addProduct = data;
        // console.log(addProduct);
        if(addProduct.prodCategory != null ||addProduct.prodCategory != undefined ) {
        ProductBasket.create(addProduct, (err, respo) => {
            if (err) return err;

            let response = { message: 'Product added successfully.' }
            cb(null, response)
        });
    } else {
        cb(null,{message : 'Oops Somethings went wrong !!!'})
    }
    }

    ProductBasket.remoteMethod('addItems', {
        http: { path: '/addItems', verb: 'post' },
        accepts: { arg: 'data', type: 'object', http: { source: 'body' } },
        returns: { arg: 'resultObjects', type: ['event'], root: true }
    });

    ///////////////////////// update basket with each count ////////////////////////

    ProductBasket.updatingEachItems = function (data, cb) {
        var totalProd_Quantity = data.totalNumber;
        var prodId = data.prodId;
        var prodPrice = data.prodPrice;
        ProductBasket.findOne({ where: { prodId: prodId, prodPrice: prodPrice } }, function (err, res) {

            if (res != null) {
                let prodPrice = res.prodPrice
                let ProductBasket_Table = `UPDATE  PRODUCT_BASKET SET PROD_COUNT = ${totalProd_Quantity} WHERE PROD_PRICE = ${prodPrice}`
                datasource.connector.execute(ProductBasket_Table, null, (err, resultObjects) => {
                    if (err) {
                        return err;
                    }
                    // QueryMsg = resultObjects;
                    // console.log(resultObjects);
                    let response = { "message": "Quantity added successfully." }
                    cb(null, response)
                });

            } else {

                cb(null, { "Message": "Oops Somethings went wrong !!!!!!!!!!" });
                return;

            }
        })

    }

    ProductBasket.remoteMethod('updatingEachItems', {
        http: { path: '/updating_Items', verb: 'post' },
        accepts: { arg: 'data', type: 'object', http: { source: 'body' } },
        returns: { arg: 'resultObjects', type: ['event'], root: true }
    });

}