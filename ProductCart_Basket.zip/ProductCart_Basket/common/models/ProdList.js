'use strict';
var path = require('path');
var server = require(path.resolve(__dirname,'../..'));
var datasource = server.datasources.loopback;

module.exports = function(ProductBasket) {

    ProductBasket.addProduct = function(data,cb){
       var addProduct = data;
       if(addProduct.prodCategory != null ||addProduct.prodCategory != undefined ) {
        ProductBasket.create(addProduct, (err, respo) => {
            if (err) return err;
            let response = {
                message : 'Product added Successfully.'
            }
            cb(null, response)
        });
       } else {
           cb(null,{'message' : 'Oops Somethings went wrong !!!!'})
       }
       
}

ProductBasket.remoteMethod('addProduct',{
    http: {path:'/product', verb:'post'},
    accepts:{arg:'data', type:'object', http:{source:'body'}},
    returns:{arg:'resultObjects',type:['event'],root: true}
});
}